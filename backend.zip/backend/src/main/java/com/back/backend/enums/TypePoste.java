package com.back.backend.enums;

public enum TypePoste {
NORMAL  , CAUMMUNAUTE
}
