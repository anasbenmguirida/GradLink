package com.back.backend.enums;

public enum Role {
ETUDIANT , LAUREAT , ADMIN 

}
