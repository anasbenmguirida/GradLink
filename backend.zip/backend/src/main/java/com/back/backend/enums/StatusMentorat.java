package com.back.backend.enums;

public enum StatusMentorat {
PENDING , ACCEPTED , REJECTED ;
}
