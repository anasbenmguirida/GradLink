import { Component } from '@angular/core';

@Component({
  selector: 'app-post-message',
  standalone: true,
  imports: [],
  templateUrl: './post-message.component.html',
  styleUrl: './post-message.component.css'
})
export class PostMessageComponent {

}
