import { ScrollRevealDirective } from './scroll-reveal.directive';

describe('ScrollRevealDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollRevealDirective();
    expect(directive).toBeTruthy();
  });
});
